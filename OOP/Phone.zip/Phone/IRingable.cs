namespace Phone
{
    public interface IRingable
    {
        string Ring();
        string Unlock();
    }
}