using System;
using System.Linq;

namespace DeckOfCards
{
    public class Soldier
    {
        public int strength = 5;
    }
}